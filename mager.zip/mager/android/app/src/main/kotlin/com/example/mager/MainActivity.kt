package com.dongker.mager

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
