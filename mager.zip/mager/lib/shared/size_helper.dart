double buttonRadius = 6;
double cardRadius1 = 12;
double cardRadius2 = 20;

double defaultMargin = 16;
double defaultBottomMargin = 40;

double margin4 = 4;
double margin8 = 8;
double margin16 = 16;
double margin24 = 24;
double margin32 = 32;
double margin40 = 40;
double margin48 = 48;
double margin56 = 56;
double margin64 = 64;
double margin72 = 72;
double margin80 = 80;
