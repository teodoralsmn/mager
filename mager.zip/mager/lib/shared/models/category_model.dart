class CategoryModel {
  late String id;
  late String category;

  CategoryModel({required this.id, required this.category});
}
